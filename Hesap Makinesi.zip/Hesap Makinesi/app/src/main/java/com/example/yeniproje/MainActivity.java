package com.example.yeniproje;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult;
    private String currentInput = "0";
    private String operator = "";
    private double firstOperand = 0;
    private boolean isOperatorClicked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tvResult);
        tvResult.setText(currentInput);

        setupButtonClickListeners();
    }

    private void setupButtonClickListeners() {
        // Sayı butonları
        int[] numberButtonIds = {R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4, R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9};
        for (int id : numberButtonIds) {
            findViewById(id).setOnClickListener(v -> appendNumber(((Button) v).getText().toString()));
        }

        // İşlem butonları
        findViewById(R.id.btnPlus).setOnClickListener(v -> setOperator("+")); // + Tuşu
        findViewById(R.id.btnEqual1).setOnClickListener(v -> setOperator("-")); // - Tuşu
        findViewById(R.id.btnCarp).setOnClickListener(v -> setOperator("*")); // * Tuşu
        findViewById(R.id.btnBol).setOnClickListener(v -> setOperator("/")); // / Tuşu

        // Diğer butonlar
        findViewById(R.id.btnEqual).setOnClickListener(v -> calculateResult()); // = Tuşu
        findViewById(R.id.btnC).setOnClickListener(v -> clearAll()); // C (Temizle) Tuşu
        findViewById(R.id.btnCE).setOnClickListener(v -> clearEntry()); // CE (Girişi Temizle) Tuşu
        findViewById(R.id.btnNokta).setOnClickListener(v -> appendDecimal()); // . (Ondalık) Tuşu
        findViewById(R.id.btnIsaret).setOnClickListener(v -> toggleSign()); // +/- (İşaret Değiştir) Tuşu
        findViewById(R.id.btnYuzde).setOnClickListener(v -> calculatePercentage()); // % (Yüzde) Tuşu
        findViewById(R.id.btnTers).setOnClickListener(v -> calculateReciprocal()); // 1/x (Ters) Tuşu
        findViewById(R.id.btnKare).setOnClickListener(v -> calculateSquare()); // x² (Kare) Tuşu
        findViewById(R.id.btnKarekok).setOnClickListener(v -> calculateSquareRoot()); // √ (Karekök) Tuşu
        findViewById(R.id.btnSil).setOnClickListener(v -> deleteLast()); // ⌫ (Sil) Tuşu
    }

    private void appendNumber(String number) {
        if (currentInput.equals("0") || isOperatorClicked) {
            currentInput = number;
            isOperatorClicked = false;
        } else {
            currentInput += number;
        }
        tvResult.setText(currentInput);
    }

    private void setOperator(String op) {
        if (!operator.isEmpty() && !isOperatorClicked) {
            calculateResult();
        }
        firstOperand = Double.parseDouble(currentInput);
        operator = op;
        isOperatorClicked = true;
    }

    private void calculateResult() {
        if (operator.isEmpty()) return;

        double secondOperand = Double.parseDouble(currentInput);
        double result = 0;

        try {
            switch (operator) {
                case "+":
                    result = firstOperand + secondOperand;
                    break;
                case "-":
                    result = firstOperand - secondOperand;
                    break;
                case "*":
                    result = firstOperand * secondOperand;
                    break;
                case "/":
                    if (secondOperand != 0) {
                        result = firstOperand / secondOperand;
                    } else {
                        tvResult.setText("Error");
                        return;
                    }
                    break;
            }
            currentInput = formatResult(result);
            tvResult.setText(currentInput);
        } catch (Exception e) {
            tvResult.setText("Error");
        }
        operator = "";
        isOperatorClicked = false;
    }

    private void clearAll() {
        currentInput = "0";
        operator = "";
        firstOperand = 0;
        tvResult.setText(currentInput);
        isOperatorClicked = false;
    }

    private void clearEntry() {
        currentInput = "0";
        tvResult.setText(currentInput);
        isOperatorClicked = false;
    }

    private void appendDecimal() {
        if (!currentInput.contains(".")) {
            currentInput += ".";
        }
        tvResult.setText(currentInput);
    }

    private void toggleSign() {
        if (!currentInput.equals("0")) {
            if (currentInput.startsWith("-")) {
                currentInput = currentInput.substring(1);
            } else {
                currentInput = "-" + currentInput;
            }
            tvResult.setText(currentInput);
        }
    }

    private void calculatePercentage() {
        double value = Double.parseDouble(currentInput) / 100;
        currentInput = formatResult(value);
        tvResult.setText(currentInput);
    }

    private void calculateReciprocal() {
        double value = 1 / Double.parseDouble(currentInput);
        currentInput = formatResult(value);
        tvResult.setText(currentInput);
    }

    private void calculateSquare() {
        double value = Math.pow(Double.parseDouble(currentInput), 2);
        currentInput = formatResult(value);
        tvResult.setText(currentInput);
    }

    private void calculateSquareRoot() {
        double value = Math.sqrt(Double.parseDouble(currentInput));
        currentInput = formatResult(value);
        tvResult.setText(currentInput);
    }

    private void deleteLast() {
        if (currentInput.length() > 1) {
            currentInput = currentInput.substring(0, currentInput.length() - 1);
        } else {
            currentInput = "0";
        }
        tvResult.setText(currentInput);
    }

    private String formatResult(double result) {
        DecimalFormat decimalFormat = new DecimalFormat("0.########");
        return decimalFormat.format(result);
    }
}